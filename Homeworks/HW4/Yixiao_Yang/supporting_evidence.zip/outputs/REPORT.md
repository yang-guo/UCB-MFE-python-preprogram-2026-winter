# HW4 findings — Yixiao Yang

## 1. Completed experiment and result

The recorded portfolio now covers **April 1, 2016 through September 30, 2026**,
all **2,640 market sessions**, with the original $1,000,000 principal.
The full course database was verified against its published SHA-256 before use.
The strategy **underperformed** the S&P 500 total-return benchmark by
**$3,091,017.72** of final value. The signed cumulative-return difference is
**-309.10 percentage points**, and the
signed CAGR difference is **-12.55 percentage points**.
These are simulated results under the stated data and execution assumptions.

| Metric | Strategy, net of modeled costs | S&P 500 total return |
| --- | --- | --- |
| Final portfolio value | $1,311,729.05 | $4,402,746.78 |
| Cumulative return | 31.17% | 340.27% |
| CAGR | 2.62% | 15.17% |
| Maximum drawdown (signed) | -69.40% | -33.79% |
| Daily-return Sharpe; 2% annual risk-free | 0.1903 | 0.7725 |

![Strategy and benchmark cumulative returns](cumulative_returns.png)

The original unaugmented run stopped at BID in October 2019. Its failure
summary and original fit/validation evidence are retained in the supporting
evidence ZIP under `verification/original_incomplete_attempt/`. I investigated
the security identity and mandatory consideration, then completed accounting
with source-verified corporate actions and missing historical observations.
**The 249,796 forecasts, alpha, features, ranking and allocation rules were
not retuned.** Original prediction SHA-256: `fdb6fc0c8a176b72b00d8125e4350f98a32c1afd77f53b96929c96f70295ac82`.
This is a repaired accounting evaluation of the same frozen experiment,
not a claim that the final period remained unseen during the investigation.

## 2. Model, features and information timing

Ridge regression predicts the gross adjusted-price return from the next
session's entry close to the first market session on or after entry plus
90 calendar days. Ridge was chosen as a transparent numeric baseline with
one regularization parameter; strong performance was not assumed.

The 12 inputs are 21- and 63-session momentum; 252-session momentum excluding
the latest 21 sessions; annualized 63-session return volatility; drawdown
from the 252-session high; quarterly net margin, operating income/assets,
debt/assets, cash/assets, free cash flow/assets, accruals/assets; and filing
age in days. Exact formulas are in `../HW4.ipynb` and `../data.py`.

Price features use only the signal close and earlier observations. They
are calculated without filling gaps. Quarterly financial reports become
available at filing date plus one calendar day. Backward joins exclude
future reports, reject filing dates on/before fiscal period end, and prevent
a late filing of an older fiscal period from displacing a newer known one.
Financial ratios become missing after 550 days from fiscal end.

Every fit learns feature clipping at its training 1st/99th percentiles,
median imputation with missing indicators, and standardization only on its
training sample. This clips input features, **not the target return**.
Current sector and active-status snapshots are not model inputs or screens.

Eligibility requires historical entry-quarter membership and 63 complete
trailing daily returns. Inactive securities remain in the union. A missing
future exit quote does not remove a prediction candidate. Once purchased,
a lot remains held if the issuer leaves subsequent quarterly universes.

## 3. Development validation and the unsuccessful modeling result

Development entries are January 2010–December 2015. Annual chronological
validation folds use entry years 2013, 2014 and 2015. A fit includes only
signals before its date and targets whose exact 90-day exit is strictly
earlier than the fit. Validation used outcomes ending by December 31, 2015.
The January–March 2016 buffer permits earlier targets to finish, with no
sampled entry dates in that buffer. The final-period rule makes quarterly
expanding-window refits using newly completed outcomes, holding the design
and chosen alpha fixed. All 42 final fit dates are exported.

The prespecified rule minimizes the equally weighted mean annual RMSE among
alpha 10, 100 and 1000; ties favor the smaller alpha. It selected **1000**.

| Model | Mean annual validation RMSE (decimal return) |
| --- | --- |
| Ridge, alpha=10 | 10.456455 |
| Ridge, alpha=100 | 10.440347 |
| Ridge, alpha=1000 | 10.284590 |
| Training-mean prediction | 1.964643 |

| Validation year | Evaluated labels | RMSE | Mean monthly rank IC |
| --- | --- | --- | --- |
| 2013 | 23,802 | 13.542328 | 0.019239 |
| 2014 | 23,841 | 9.442899 | -0.043601 |
| 2015 | 19,895 | 7.868542 | -0.075035 |

The selected Ridge performs worse than the training-mean reference in
development RMSE, with negative mean rank IC in two validation years.
This is an unsuccessful baseline, not evidence of a reliable predictive edge.
The reference model was a diagnostic, not an unrecorded portfolio-selection
alternative. I preserved the originally specified Ridge experiment rather
than switching models after viewing the final path.

Independent SQL diagnosis found **137,420**
eligible labels completed by the development cutoff. Of these, 17 exceed a
decimal return of 10, five exceed 100, and two exceed 1,000. The most extreme
AAM observation uses an entry adjusted price of 0.1915 and an exit value of
20,461.50, implying a decimal return of about 106,847.56. These positive finite
numbers pass a basic numeric check but are not verified economic returns.
The largest training target accounts for about 79.4% of centered squared
deviations in the 2013 fold; the largest ten account for about 99.997%.
Feature clipping cannot fix such target contamination. The training-mean
baseline also inherits the contaminated mean. See `data_issues.json` and
`extreme_development_labels.csv` for the original evidence.

## 4. Portfolio construction and accounting

At the last close before each month's first market session, eligible names
are ranked by predicted return, then ticker for ties. Up to 20 fixed orders
are scheduled for the next session's close. A cohort's inclusive budget is
`min(previous-close available cash, previous-close NAV / 3)`, with one
twentieth assigned to each selected slot. Fewer candidates leave cash unused.
Same-day maturity receipts cannot increase orders already decided yesterday.

The account uses fractional adjusted-price units, long-only holdings, no
borrowing and no leverage. A buy with inclusive budget B at adjusted price P
receives `B / (P × 1.001)` units. Ordinary sales return `units × P × 0.999`.
Cash earns 0%. Each lot has its own 90-calendar-day maturity; a market closure
rolls the exit to the next session. Repeated monthly positions in one issuer
can overlap, so there is no aggregate issuer-weight cap.

Dividends are not separately added to adjusted-price returns. At the test
end, still-open lots are marked rather than forcibly sold. Their later
maturities and prices after September 30, 2026 are not used.

| Accounting event | Recorded lot events |
| --- | --- |
| BUY | 2459 |
| SELL | 2401 |
| CASH_MERGER_CONVERSION | 18 |
| CASH_CLAIM_RELEASE | 18 |
| SECURITY_CONVERSION | 2 |

Final available cash is **$423,045.31**, stocks are
**$888,683.74**, and cash claims are
**$0.00**, totaling **$1,311,729.05**.
There are **40** open lots, with
**0** stale final marks.
Total modeled costs are **$62,168.58**. Average available cash
as a fraction of daily NAV is **21.57%**.
`trades.csv`, `orders.csv`, `open_positions.csv` and `daily_nav.csv` provide
the corresponding accounting trail.

## 5. Corporate actions and missing observations

The original strict rule still cancels a missing-entry order without reranking,
carries an ordinary missing mark for at most five sessions, and stops at a
missing maturity quote or a sixth stale session. The completed path did not
require disabling those checks. Instead, sourced observations or legally
verified consideration resolve the relevant data gaps.

The separate evidence registry covers **22** events or
identity continuations: ALPN, ASGN, BID, BSGM, BVH, CCXI, CIFRW, DISH, ECOL, FI, GPS, HOUS, IMGN, MAXR, MFH, NCR, PEGY, RCB, RETA, RXDX, SOFIW, TA. Full dates, amounts, unit formulas
and primary-source links appear in [CORPORATE_ACTIONS.md](CORPORATE_ACTIONS.md)
and `../corporate_actions.json`.

For a mandatory cash merger or redemption, the stock/instrument converts to
a fixed cash claim on the effective daily accounting date. The conversion
does not create a fictitious exchange sale. The claim counts in NAV but is
ring-fenced from new purchases until the lot's original maturity, when one
modeled exit charge is applied. This explicitly preserves the original
capital-allocation horizon. Actual broker payment timing and investor-specific
taxes are not observable or modeled. For mandatory stock mergers, units convert
to the sourced successor ratio while cost and original maturity remain intact.

Some original eligible names are warrants or baby bonds despite being in
the course's stock universe. The frozen no-exercise strategy receives the
mandatory default cash redemption for SOFIW and CIFRW; the optional, more
valuable cashless exercise is not retroactively chosen. RCB is a 6.2% note,
so its mandatory redemption includes the contractually accrued interest;
the evidence appendix shows that calculation. These instrument-classification
problems are substantive limitations of the original selection experiment.

Pure renames use observed successor quotes, with an explicit adjustment-basis
bridge where necessary. The NCR lot entered after the earlier NCR/NATL split,
so it receives no historical spinoff distribution. Historical WOLF prices are
required for its 2024 holding; its 2025 reorganization cannot supply those
earlier values. Likewise, Sotheby's 2019 BID holding is not connected to a
different issuer later reusing BID. No missing position is silently deleted,
assigned its last quote as a cash payoff, or written to zero without evidence.

These repairs only enter portfolio accounting. Features and training targets
still use the original course observations. Consequently, future legal-identity
research or a currently retrieved price cannot improve earlier model inputs.
The original dataset's remaining positive-but-economically-wrong prices are
not all independently certified merely because the ledger now reconciles.

## 6. Benchmark, metrics and risk

The comparator buys $1,000,000 of `^SP500TR` at the April 1, 2016 close and
holds through September 30, 2026. Both paths have a prior-session $1,000,000
anchor, so the strategy's initial transaction costs are included. CAGR uses
elapsed calendar days between the first and final test closes divided by
365.25. Maximum drawdown uses running portfolio highs and is reported as a
negative percentage. Sharpe uses arithmetic daily excess returns over
`1.02**(1/252) - 1`, sample daily standard deviation, and `sqrt(252)`.

Annual compounded returns, including the two partial calendar years, are:

| Year | Strategy | Benchmark |
| --- | --- | --- |
| 2016 (partial) | 20.68% | 9.78% |
| 2017 | -2.23% | 21.83% |
| 2018 | -31.62% | -4.38% |
| 2019 | 1.68% | 31.49% |
| 2020 | 32.45% | 18.40% |
| 2021 | 2.47% | 28.71% |
| 2022 | -43.45% | -18.11% |
| 2023 | 8.51% | 26.29% |
| 2024 | -5.43% | 25.02% |
| 2025 | 58.36% | 17.88% |
| 2026 (partial) | 28.19% | 12.75% |

This is an unhedged stock/instrument-selection strategy. It takes concentrated
exposure through repeated cohorts, pays trading costs and leaves material
cash uninvested. Its price and financial signals do not constrain issuer
quality, liquidity, market beta or aggregate security weight. Corporate-action
losses, extreme source labels and changing exposure all affect the outcome;
the comparison is not risk-matched to a permanently invested large-cap index.

The five largest individual realized lot losses illustrate what actually
happened; they are not a post-test screening list:

| Original security | Entry | Exit/release | Net realized P&L |
| --- | --- | --- | --- |
| SOFIW | 2021-12-01 | 2022-03-01 | $-20,676.40 |
| CIFRW | 2025-11-03 | 2026-02-02 | $-18,916.40 |
| INPX | 2017-04-03 | 2017-07-03 | $-16,421.43 |
| CIFRW | 2025-12-01 | 2026-03-02 | $-16,345.33 |
| INPX | 2017-06-01 | 2017-08-30 | $-15,691.58 |

## 7. Verification and reproducibility

Hand-calculated tests cover fees, cash conservation, overlapping lots,
weekend maturity, fixed budgets, stale and missing quotes, terminal value,
claim conversion/release and stock exchanges. Information-timing tests cover
filing availability, historical membership, target purging and invariance
of earlier features/predictions to changed future inputs. Synthetic fixtures
are used only for checks, not for reported investment results.

The independent reconstruction is included in `FULL_ACCOUNTING_AUDIT.json`. It reads the original database, evidence overlay and event ledger without importing the backtester, then recomputes cash, holdings, NAV, maturity dates, prior-close order budgets and risk metrics.

The original official database checksum is `a028641d96c12e6f29d5dd34e3a6ebc059074dd38351648bf0d970b1dd4095b9`.
`run_config.json` records the original protocol and the separate evidence
fingerprint. `../verification/FROZEN_STRATEGY.json` and the compressed forecast
file permit an exact replay of the same decisions. `python hw4.py --replay
--database PATH --output outputs` replays the supplied forecasts. `python
hw4.py --database PATH` regenerates features, development validation,
quarterly predictions and the same source-reconciled accounting. Minor
floating-point prediction differences across numerical-library versions
are possible; the supplied frozen replay is byte-verifiable.

## 8. Main limitations and next experiment

The course data contain 3,849 securities,
including 1,355 currently inactive
names retained for historical use. Quarterly membership is reconstructed,
not a certified point-in-time feed. Vendor financials may be restated;
filing-date joins cannot undo that. Some security types, issuer identities
and share/split bases are inconsistent, and missing outcomes can bias the
available training-label sample. Overlapping 90-day outcomes are dependent.

Accounting completion does not establish that this is a deployable strategy.
The fixed Ridge model has a clearly weak validation record, severe label
contamination and no demonstrated edge over the benchmark. A next experiment
should first establish stable security IDs and instrument types, verify
split-adjusted targets, and compare robust target treatment, a price-only
baseline and the financial model using development data alone. Liquidity,
issuer caps, costs and cash rules should also be set there. Any changes after
this review require a separately declared experiment and genuinely new
evaluation data; they should not be advertised as a newly untouched test
of the same 2016–2026 period.

## 9. Sources and AI-assisted work

- [HW4 assignment](https://github.com/yang-guo/UCB-MFE-python-preprogram-2026-winter/blob/5212932d7d2e9de49785ee2c7e0395579b42d694/Lectures/Lecture%208/hw4.md).
- [Course data guide](https://github.com/yang-guo/UCB-MFE-python-preprogram-2026-winter/blob/5212932d7d2e9de49785ee2c7e0395579b42d694/Lectures/modeling/README.md).
- [Adapted data/preprocessing conventions](https://github.com/yang-guo/UCB-MFE-python-preprogram-2026-winter/blob/5212932d7d2e9de49785ee2c7e0395579b42d694/Lectures/modeling/course_data.py).
- Corporate-action and supplemental-price sources are linked in the evidence
  appendix and stored alongside their inputs. The database itself is unmodified.

The backtester is a separate implementation for this homework. ChatGPT
assisted with code, source investigation, tests, accounting reconciliation,
documentation and report generation. Numerical statements are calculated
from the supplied data and explicit evidence overlay; they are not invented
example outputs. This package prepares the assignment for review and does
not itself publish a GitHub pull request.
