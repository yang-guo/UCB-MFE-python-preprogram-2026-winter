# Corporate actions and security continuity

This appendix identifies the economic holdings behind legacy research tickers. These inputs repair portfolio accounting only. They do not change model features, labels, predictions, historical membership, or the selected names.

Mandatory cash consideration becomes a non-spendable cash claim on the event's accounting date. It remains at fixed value until the original 90-calendar-day maturity, then releases with the strategy's one modeled 10-basis-point exit charge. Actual broker-credit delays are not observed. The fee is a simulation convention, not a claim about issuer commissions. Mandatory share conversions preserve the original maturity and cost basis. Fractional adjusted-price units are allowed throughout.

The cash basis formula is `cash_per_raw_share × old_adj_close / old_close`. For a share exchange, the new adjusted-unit ratio is `raw_exchange_ratio × (old_adj/old_close) / (new_adj/new_close)`. A pure ticker alias with equal raw closes can be continued in the old adjusted-price unit using `old_adj / successor_adj` at a verified overlap. No separate dividend is credited when the adjusted-price series already includes it.

## BID — Sotheby's

| Field | Value |
| --- | --- |
| Action ID | BID_2019-10-03_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2019-10-03 |
| Cash per actual share/instrument | 57 |
| Cash per adjusted-price unit | 57 |
| Price-basis reference date | 2019-10-02 |
| Reference old raw close | 56.99 |
| Reference old adjusted close | 56.99 |

Ordinary outstanding Sotheby's common shares converted into the right to receive USD 57.00 in cash without interest at the merger effective time. Affiliate-owned shares and perfected appraisal claims are outside this simulated public-investor position.

Only open historical Sotheby's lots entered before 2019-10-03. Do not apply to any later security reusing BID.

Recognize the fixed cash entitlement on October 3, but keep it unavailable for new buys through each lot's original 90-day maturity. Sources establish the legal entitlement; the maturity lock and modeled exit fee are explicit simulation conventions, not actual merger settlement terms.

The supplied snapshot labels BID as Tribeca Strategic Acquisition Corp. and contains later 2026 prices for the reused ticker. Those snapshot fields and later prices do not identify the 2019 Sotheby's holding.

- [Sotheby's public merger announcement, SEC Exhibit 99.2](https://www.sec.gov/Archives/edgar/data/823094/000119312519174301/d766624dex992.htm): Publicly announced USD 57.00-per-share cash merger terms, subject to conditions.
- [Sotheby's closing Form 8-K, Introductory Note and Item 2.01](https://www.sec.gov/Archives/edgar/data/823094/000082309419000038/a8-kclosingxbrl.htm): Completed merger on October 3 and conversion of ordinary common shares to a USD 57.00 cash entitlement.
- [NYSE notice of removal from listing and registration](https://www.sec.gov/Archives/edgar/data/823094/000087666119001019/ruleprovisionnotice.htm): Merger effective before October 3 opening; shares exchanged for USD 57.00 cash; trading suspended October 3. Formal listing removal on October 14 is distinct from the merger date.

## SOFIW — SoFi Technologies, Inc.

| Field | Value |
| --- | --- |
| Action ID | SOFIW_2021-12-07_UNEXERCISED_WARRANT_REDEMPTION |
| Kind | unexercised_warrant_cash_redemption |
| Effective/accounting date | 2021-12-07 |
| Cash per actual share/instrument | 0.1 |
| Cash per adjusted-price unit | 0.1 |
| Price-basis reference date | 2021-12-06 |
| Reference old raw close | 5.5 |
| Reference old adjusted close | 5.5 |

Public warrants remaining unexercised at 5 p.m. New York on December 6, 2021 become void and entitle holders only to USD 0.10 per warrant.

Open SoFi public-warrant lots entered before the redemption deadline. This event does not apply to SOFI common stock or surviving Series H warrants.

Recognize the default redemption claim on the next market session, December 7, and retain it through the lot's original 90-day maturity before cash release and the single modeled exit fee.

- [SoFi notice of redemption of all outstanding public and private warrants](https://www.sec.gov/Archives/edgar/data/1818874/000181887421000072/exhibit992.htm): December 6 at 5 p.m. New York redemption deadline and USD 0.10 mandatory cash amount for unexercised public warrants.
- [SoFi redemption fair-market-value notice](https://www.sec.gov/Archives/edgar/data/1818874/000181887421000109/ex992.htm): Optional cashless exercise ratio of 0.361 common shares per warrant; unexercised warrants receive only USD 0.10.
- [SoFi announcement of completed warrant redemption](https://www.sec.gov/Archives/edgar/data/1818874/000181887421000118/exhibit991form8-k12152021.htm): Confirms redemption completed and public-warrant trading halt announced after the December 6 market close; Series H warrants were unaffected.

## ECOL — US Ecology, Inc.

| Field | Value |
| --- | --- |
| Action ID | ECOL_2022-05-02_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2022-05-02 |
| Cash per actual share/instrument | 48 |
| Cash per adjusted-price unit | 48 |
| Price-basis reference date | 2022-04-29 |
| Reference old raw close | 47.99 |
| Reference old adjusted close | 47.99 |

Only open US Ecology, Inc. common-stock lots acquired before 2022-05-02; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Republic Services closing announcement](https://investor.republicservices.com/news-releases/news-release-details/republic-services-completes-acquisition-us-ecology): Completed acquisition on May 2, 2022 for USD 48 cash per outstanding US Ecology share.
- [Republic Services merger announcement filed with the SEC](https://investor.republicservices.com/node/24451/html): Publicly announced USD 48 cash-per-share agreement.

## CCXI — ChemoCentryx, Inc.

| Field | Value |
| --- | --- |
| Action ID | CCXI_2022-10-20_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2022-10-20 |
| Cash per actual share/instrument | 52 |
| Cash per adjusted-price unit | 52 |
| Price-basis reference date | 2022-10-19 |
| Reference old raw close | 51.99 |
| Reference old adjusted close | 51.99 |

Only open ChemoCentryx, Inc. common-stock lots acquired before 2022-10-20; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Nasdaq corporate-action alert ECA2022-292](https://nasdaqtrader.com/TraderNews.aspx?id=eca2022-292): Merger closed before market open October 20; last trading October 19; USD 52 cash for each share. Suspension effective October 21 is not the cash-entitlement date.
- [Amgen closing announcement](https://www-ext.amgen.com/newsroom/press-releases/2022/10/amgen-successfully-completes-acquisition-of-chemocentryx): Completed acquisition for USD 52 per share in cash.
- [Amgen acquisition announcement](https://www.amgen.com/newsroom/press-releases/2022/08/amgen-to-acquire-chemocentryx-for-%244-billion-in-cash): Publicly announced USD 52-per-share cash acquisition.

## MAXR — Maxar Technologies Inc.

| Field | Value |
| --- | --- |
| Action ID | MAXR_2023-05-03_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2023-05-03 |
| Cash per actual share/instrument | 53 |
| Cash per adjusted-price unit | 53 |
| Price-basis reference date | 2023-05-02 |
| Reference old raw close | 52.99 |
| Reference old adjusted close | 52.99 |

Only open Maxar Technologies Inc. common-stock lots acquired before 2023-05-03; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Maxar closing Form 8-K](https://www.sec.gov/Archives/edgar/data/1121142/000110465923055309/tm2314357d3_8k.htm): Merger completed May 3; ordinary common shares automatically converted to USD 53 cash entitlement; requested removal before May 3 opening.
- [Maxar acquisition announcement, SEC Exhibit 99.1](https://www.sec.gov/Archives/edgar/data/1121142/000110465922127558/tm2232717d2_ex99-1.htm): Publicly announced USD 53-per-share cash terms.

## TA — TravelCenters of America Inc.

| Field | Value |
| --- | --- |
| Action ID | TA_2023-05-15_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2023-05-15 |
| Cash per actual share/instrument | 86 |
| Cash per adjusted-price unit | 86 |
| Price-basis reference date | 2023-05-12 |
| Reference old raw close | 86 |
| Reference old adjusted close | 86 |

Only open TravelCenters of America Inc. common-stock lots acquired before 2023-05-15; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [TravelCenters closing Form 8-K, Items 2.01 and 3.01](https://www.sec.gov/Archives/edgar/data/1378453/000110465923060301/tm2315684d1_8k.htm): Shares converted into USD 86 cash entitlement; trading ceased before market open May 15.
- [BP announcement presentation](https://www.bp.com/content/dam/bp/business-sites/en/global/corporate/pdfs/investors/bp-travelcenters-of-america-announcement-slides-and-script.pdf): Public agreement and USD 86-per-share cash consideration.

## RXDX — Prometheus Biosciences, Inc.

| Field | Value |
| --- | --- |
| Action ID | RXDX_2023-06-16_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2023-06-16 |
| Cash per actual share/instrument | 200 |
| Cash per adjusted-price unit | 199.99999799919968 |
| Price-basis reference date | 2023-06-15 |
| Reference old raw close | 199.92 |
| Reference old adjusted close | 199.919998 |

Only open Prometheus Biosciences, Inc. common-stock lots acquired before 2023-06-16; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Merck closing announcement](https://www.merck.com/news/merck-completes-acquisition-of-prometheus-biosciences-inc/): Completion on June 16; all outstanding Prometheus shares acquired for USD 200 cash per share. Release timestamp is 4:04 p.m. EDT; this is end-of-day entitlement accounting, not a market execution.
- [Merck acquisition announcement](https://www.merck.com/news/merck-strengthens-immunology-pipeline-with-acquisition-of-prometheus-biosciences-inc/): Publicly announced USD 200-per-share cash terms.

## RETA — Reata Pharmaceuticals, Inc.

| Field | Value |
| --- | --- |
| Action ID | RETA_2023-09-26_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2023-09-26 |
| Cash per actual share/instrument | 172.5 |
| Cash per adjusted-price unit | 172.5 |
| Price-basis reference date | 2023-09-25 |
| Reference old raw close | 172.36 |
| Reference old adjusted close | 172.36 |

Only open Reata Pharmaceuticals, Inc. common-stock lots acquired before 2023-09-26; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Reata closing Form 8-K](https://www.sec.gov/Archives/edgar/data/1358762/000119312523242619/d516210d8k.htm): Merger completed September 26 and ordinary Class A and Class B shares converted into USD 172.50 cash entitlement.
- [Biogen and Reata acquisition announcement](https://investors.biogen.com/news-releases/news-release-details/biogen-acquire-reata-pharmaceuticals): Publicly announced USD 172.50 cash-per-share agreement.
- [Nasdaq Equity Corporate Actions Alert 2023-540, subsequently updated to confirm closing](https://www.nasdaqtrader.com/TraderNews.aspx?id=ECA2023-540): Merger closed before September 26 market open; September 25 was last trading date; shares stayed halted on September 26; USD 172.50 consideration. Page header is the original alert date, not the closing-update timestamp.

## NCR — NCR Corporation, renamed NCR Voyix Corporation

| Field | Value |
| --- | --- |
| Action ID | NCR_2023-10-17_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2023-10-17 |
| Successor database identifier | VYX |
| Successor-price multiplier | 1 |
| Price-basis reference date | 2023-11-13 |
| Reference old raw close | 15.73 |
| Reference old adjusted close | 15.73 |
| Quote-continuation start | 2023-11-14 |
| Quote-continuation end | 2024-01-30 |

Use observed VYX adjusted prices solely for NCR from 2023-11-14 through 2024-01-30, the last needed maturity of frozen selected lots. Do not alter signals, membership, features, targets, predictions or selection.

The affected selected lot entered November 1, 2023, after the October 16 spin-off. No NATL distribution belonging to earlier holders is credited.

- [NCR Form 8-K, Item 8.01](https://www.sec.gov/Archives/edgar/data/70866/000119312523240858/d533909d8k.htm): Public September 22 announcement of October 17 NCR-to-VYX change with unchanged CUSIP.
- [NCR Voyix pro forma financial information filed with the SEC](https://www.sec.gov/Archives/edgar/data/70866/000007086623000035/discopsaoctober2023xex991.htm): Completed spin-off on October 16 and common-stock trading as VYX on October 17.

## DISH — DISH Network Corporation

| Field | Value |
| --- | --- |
| Action ID | DISH_2023-12-31_STOCK_MERGER |
| Kind | security_conversion |
| Effective/accounting date | 2023-12-31 |
| Successor database identifier | ECHO |
| Successor units per old adjusted unit | 0.350877 |
| Price-basis reference date | 2023-12-29 |
| Reference old raw close | 5.77 |
| Reference old adjusted close | 5.77 |

Convert only historical DISH holdings outstanding at the legal merger. Continue each lot as EchoStar through its original maturity; do not create additional successor purchases or apply the mapping to a later issuer reusing DISH.

- [EchoStar closing announcement filed as SEC Exhibit 99.1](https://www.sec.gov/Archives/edgar/data/1415404/000110465924000089/tm2333745d3_ex99-1.htm): December 31 completion; each DISH Class A or Class C share converted to 0.350877 EchoStar Class A shares.
- [Post-merger Schedule 13D amendment filed with the SEC](https://www.sec.gov/Archives/edgar/data/904548/000110465924001019/tm241626d1_sc13da.htm): Merger effective December 31, 2023 at 11:59 p.m. ET, with 0.350877 exchange ratio.
- [DISH merger information statement filed with the SEC](https://www.sec.gov/Archives/edgar/data/1001082/000110465923115250/tm2323753-2_defm14c.htm): Common-stock exchange ratio and official cash payment in lieu of fractional EchoStar shares.
- [EchoStar issuer ticker-change announcement](https://ir.echostar.com/news-releases/news-release-details/echostar-changing-stocker-ticker-sats-echo-marking-companys-next): SATS changes to ECHO June 24, 2026 with the same CUSIP, establishing the database's successor identity.

## BVH — Bluegreen Vacations Holding Corporation

| Field | Value |
| --- | --- |
| Action ID | BVH_2024-01-17_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2024-01-17 |
| Cash per actual share/instrument | 75 |
| Cash per adjusted-price unit | 75 |
| Price-basis reference date | 2024-01-16 |
| Reference old raw close | 75 |
| Reference old adjusted close | 75 |

Only open Bluegreen Vacations Holding Corporation common-stock lots acquired before 2024-01-17; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Bluegreen transaction Form 4, footnote F1](https://www.sec.gov/Archives/edgar/data/315858/000095017024004843/ownership.xml): January 17 merger converted each outstanding Class A and Class B common share to USD 75 cash entitlement.
- [Hilton Grand Vacations closing announcement](https://investors.hgv.com/press-releases/news-details/2024/Hilton-Grand-Vacations-Completes-Acquisition-of--Bluegreen-Vacations/default.aspx): Confirms completed Bluegreen acquisition on January 17.
- [Hilton Grand Vacations acquisition announcement, SEC Exhibit 99.2](https://www.sec.gov/Archives/edgar/data/1674168/000119312523270866/d570608dex992.htm): Publicly announced USD 75 cash per Bluegreen share.

## IMGN — ImmunoGen, Inc.

| Field | Value |
| --- | --- |
| Action ID | IMGN_2024-02-12_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2024-02-12 |
| Cash per actual share/instrument | 31.26 |
| Cash per adjusted-price unit | 31.26 |
| Price-basis reference date | 2024-02-09 |
| Reference old raw close | 31.23 |
| Reference old adjusted close | 31.23 |

Only open ImmunoGen, Inc. common-stock lots acquired before 2024-02-12; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [AbbVie closing announcement](https://news.abbvie.com/2024-02-12-AbbVie-Completes-Acquisition-of-ImmunoGen): Acquired all ImmunoGen common stock for USD 31.26 per share, with cessation expected before February 12 market open.
- [AbbVie acquisition announcement](https://news.abbvie.com/2023-11-30-AbbVie-to-Acquire-ImmunoGen%2C-including-its-Flagship-Cancer-Therapy-ELAHERE-R-mirvetuximab-soravtansine-gynx-%2C-Expanding-Solid-Tumor-Portfolio?trk=article-ssr-frontend-pulse_little-text-block): Publicly announced USD 31.26 cash per ImmunoGen share.

## ALPN — Alpine Immune Sciences, Inc.

| Field | Value |
| --- | --- |
| Action ID | ALPN_2024-05-20_CASH_MERGER |
| Kind | cash_merger |
| Effective/accounting date | 2024-05-20 |
| Cash per actual share/instrument | 65 |
| Cash per adjusted-price unit | 65 |
| Price-basis reference date | 2024-05-17 |
| Reference old raw close | 64.97 |
| Reference old adjusted close | 64.97 |

Only open Alpine Immune Sciences, Inc. common-stock lots acquired before 2024-05-20; no application to a different issuer reusing the symbol.

Recognize fixed cash entitlement on the event date; keep it unavailable to new buys until each lot's original 90-calendar-day maturity and then release with the single modeled 10-basis-point exit fee. These timing/cost conventions are simulated, not asserted actual broker settlement terms.

- [Alpine tender-offer amendment confirming completed merger](https://www.sec.gov/Archives/edgar/data/1626199/000119312524142270/d817511dsc14d9a.htm): Tender offer completed, and Vertex completed the statutory merger on May 20; remaining shares cease trading and are delisted.
- [Offer to Purchase filed with the SEC](https://www.sec.gov/Archives/edgar/data/1626199/000119312524104867/d816533dex99a1a.htm): USD 65 cash per common share offer and subsequent merger terms.
- [Vertex and Alpine acquisition announcement](https://investors.vrtx.com/news-releases/news-release-details/vertex-enters-agreement-acquire-alpine-immune-sciences): Publicly announced USD 65-per-share cash acquisition.
- [Nasdaq Equity Corporate Actions Alert 2024-229, updated to confirm closing](https://www.nasdaqtrader.com/TraderNews.aspx?id=ECA2024-229): Subsequent merger closed before the May 20 market opening; May 17 was last trading date; USD 65 consideration; May 21 administrative suspension.

## GPS — The Gap, Inc.

| Field | Value |
| --- | --- |
| Action ID | GPS_2024-08-22_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2024-08-22 |
| Successor database identifier | GAP |
| Successor-price multiplier | 1.0074962518740629 |
| Price-basis reference date | 2024-09-18 |
| Reference old raw close | 20.16 |
| Reference old adjusted close | 20.16 |
| Quote-continuation start | 2024-09-19 |
| Quote-continuation end | 2024-09-30 |

Use observed GAP adjusted prices solely for GPS from 2024-09-19 through 2024-09-30, the last needed maturity of frozen selected lots. Do not alter signals, membership, features, targets, predictions or selection.

The affected lot entered July 1, 2024. Identical overlapping raw quotes but different adjusted bases require multiplying the successor adjusted series by 20.16/20.01.

- [Gap issuer announcement](https://investors.gapinc.com/press-releases/news-details/2024/Gap-Inc.-To-Change-Ticker-Symbol-to-GAP-on-August-22-To-Report-Second-Quarter-Fiscal-2024-Results-on-August-29/default.aspx): GPS-to-GAP change effective August 22 with unchanged CUSIP and no shareholder action.

## PEGY — Pineapple Energy Inc., renamed SUNation Energy, Inc.

| Field | Value |
| --- | --- |
| Action ID | PEGY_2024-11-19_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2024-11-19 |
| Successor database identifier | SUNE |
| Successor-price multiplier | 0.005 |
| Price-basis reference date | 2024-11-19 |
| Reference old raw close | 3.4 |
| Reference old adjusted close | 3.4 |
| Quote-continuation start | 2024-11-20 |
| Quote-continuation end | 2024-12-02 |

Only fill documented missing accounting observations for frozen PEGY lots from 2024-11-20 through 2024-12-02. No signal, feature, training label, prediction, or eligibility changes.

Thirteen overlap dates from November 1–19 have the exact course/provider ratio 0.005. The provider's historic close and adjusted close include a later 1-for-200 reverse split; its 680 value is not the contemporaneous USD 3.40 as-traded raw quote. Normalize only these 2024 accounting observations by 1/200; do not apply the later share conversion to a lot that matured in 2024.

- [Issuer corporate name/ticker change announcement or SEC current report](https://ir.sunation.com/news-events/press-releases/detail/85/pineapple-energy-announces-corporate-name-change-to): November 19 ticker change from PEGY to SUNE; issuer confirms unchanged CUSIP and no shareholder action.
- [SUNation Form S-3, corporate background and selected financial data](https://www.sec.gov/Archives/edgar/data/22701/000121390025033892/ea0238874-s3_sunation.htm): April 16 certificate amendment and April 21, 2025 00:01 ET implementation of a 1-for-200 reverse split; explains the vendor history basis.

## BSGM — BioSig Technologies, Inc., renamed Streamex Corp.

| Field | Value |
| --- | --- |
| Action ID | BSGM_2025-09-12_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2025-09-12 |
| Successor database identifier | STEX |
| Successor-price multiplier | 1 |
| Price-basis reference date | 2025-09-11 |
| Reference old raw close | 6.1 |
| Reference old adjusted close | 6.1 |
| Quote-continuation start | 2025-09-12 |
| Quote-continuation end | 2025-12-01 |

Only fill documented missing accounting observations for frozen BSGM lots from 2025-09-12 through 2025-12-01. No signal, feature, training label, prediction, or eligibility changes.

Thirteen overlapping dates agree to floating-point serialization precision. Use exact unit multiplier 1, not a fitted noise-scale median. No in-window dividend or split event is returned by the provider.

- [Issuer corporate name/ticker change announcement or SEC current report](https://www.sec.gov/Archives/edgar/data/1530766/000164117225027127/form8-k.htm): BSGM becomes STEX before the September 12 opening, with unchanged CUSIP and security-holder rights.

## FI — Fiserv, Inc.

| Field | Value |
| --- | --- |
| Action ID | FI_2025-11-11_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2025-11-11 |
| Successor database identifier | FISV |
| Successor-price multiplier | 1 |
| Price-basis reference date | 2025-11-11 |
| Reference old raw close | 64.26 |
| Reference old adjusted close | 64.26 |
| Quote-continuation start | 2025-11-12 |
| Quote-continuation end | 2026-02-02 |

Use observed FISV adjusted prices solely for FI from 2025-11-12 through 2026-02-02, the last needed maturity of frozen selected lots. Do not alter signals, membership, features, targets, predictions or selection.

This is the same common equity under a new ticker and listing market, not a sale or a new purchase.

- [Nasdaq Data Technical News 2025-32](https://www.nasdaqtrader.com/TraderNews.aspx?id=DTN2025-32): November 11 exchange transfer and FI-to-FISV mapping; both share symbols have CUSIP 337738108. Nasdaq instructs data vendors to maintain FI history under FISV.
- [Fiserv issuer announcement](https://investors.fiserv.com/news-releases/news-release-details/fiserv-announces-transfer-stock-exchange-listing-nasdaq): Public announcement of the November 11 listing transfer and return to ticker FISV.

## MFH — Mercurity Fintech Holding Inc., renamed Chaince Digital Holdings Inc.

| Field | Value |
| --- | --- |
| Action ID | MFH_2025-11-13_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2025-11-13 |
| Successor database identifier | CD |
| Successor-price multiplier | 1 |
| Price-basis reference date | 2026-01-12 |
| Reference old raw close | 4.74 |
| Reference old adjusted close | 4.74 |
| Quote-continuation start | 2026-01-13 |
| Quote-continuation end | 2026-02-02 |

Use observed CD adjusted prices solely for MFH from 2026-01-13 through 2026-02-02, the last needed maturity of frozen selected lots. Do not alter signals, membership, features, targets, predictions or selection.

The ordinary shares are the same security after the name change; the continuation is limited to the original frozen lots' maturity.

- [Issuer name and ticker-change announcement filed as SEC Exhibit 99.1](https://www.sec.gov/Archives/edgar/data/1527762/000149315225021857/ex99-1.htm): November 13 opening change from MFH to CD; unchanged CUSIP, share count, par value and shareholder rights.

## CIFRW — Cipher Mining Inc.

| Field | Value |
| --- | --- |
| Action ID | CIFRW_2025-12-29_UNEXERCISED_WARRANT_REDEMPTION |
| Kind | unexercised_warrant_cash_redemption |
| Effective/accounting date | 2025-12-29 |
| Cash per actual share/instrument | 0.01 |
| Cash per adjusted-price unit | 0.01 |
| Price-basis reference date | 2025-12-26 |
| Reference old raw close | 4.09 |
| Reference old adjusted close | 4.09 |

Outstanding unexercised called public warrants receive USD 0.01 each. The pre-deadline cashless exercise option for 0.2687 common shares was an affirmative election and is not assumed by this strategy.

Only the historical Cipher Mining public warrant held across the December 26, 2025 redemption deadline. No synthetic warrant exercise or successor common-share position is created.

Recognize a fixed cash claim at the effective event's daily close. Do not add it to spendable cash or fund new buys before that lot's original 90-calendar-day maturity (rolled to the next market session). Release the claim only at that scheduled maturity. This conservative lock preserves the original allocation horizon; it is a simulation convention, not a claim about the broker's actual credit date.

- [Nasdaq Equity Corporate Actions Alert 2025-700](https://www.nasdaqtrader.com/TraderNews.aspx?id=ECA2025-700): November 26 announcement; December 26 17:00 deadline; USD 0.01 mandatory redemption for remaining warrants; December 29 suspension; separate elective cashless terms.

## HOUS — Anywhere Real Estate Inc.

| Field | Value |
| --- | --- |
| Action ID | HOUS_2026-01-09_STOCK_MERGER |
| Kind | security_conversion |
| Effective/accounting date | 2026-01-09 |
| Successor database identifier | COMP |
| Successor units per old adjusted unit | 1.436 |
| Price-basis reference date | 2026-01-08 |
| Reference old raw close | 17.64 |
| Reference old adjusted close | 17.64 |

Convert only Anywhere common-share holdings outstanding at merger completion. Preserve each original lot and scheduled maturity under the successor COMP holding.

- [Compass closing Form 8-K, Introductory Note and Item 2.01](https://investors.compass.com/sec-filings/all-sec-filings/content/0001563190-26-000019/comp-20260109.htm): January 9 completion and conversion of ordinary Anywhere common stock to 1.436 Compass common shares, with cash in lieu of fractional shares under the official terms.

## RCB — Ready Capital Corporation

| Field | Value |
| --- | --- |
| Action ID | RCB_2026-04-22_NOTE_REDEMPTION |
| Kind | note_cash_redemption |
| Effective/accounting date | 2026-04-22 |
| Cash per actual share/instrument | 25.353055555555557 |
| Cash per adjusted-price unit | 25.353055555555557 |
| Price-basis reference date | 2026-04-21 |
| Reference old raw close | 25.34 |
| Reference old adjusted close | 25.34 |

Each USD 25 note is redeemed for principal plus accrued interest through the day before redemption. The USD 25.353055555555557 amount is calculated from the disclosed coupon and day-count terms, not copied from a printed settlement amount.

Only outstanding Ready Capital 6.20% senior-note lots held at April 22, 2026.

Recognize a fixed cash claim at the effective event's daily close. Do not add it to spendable cash or fund new buys before that lot's original 90-calendar-day maturity (rolled to the next market session). Release the claim only at that scheduled maturity. This conservative lock preserves the original allocation horizon; it is a simulation convention, not a claim about the broker's actual credit date.

- [Ready Capital Form 8-K, Item 8.01](https://www.sec.gov/Archives/edgar/data/1527590/000110465926033443/tm269619d1_8k.htm): April 22 redemption of all outstanding 6.20% notes for 100% principal plus interest accrued to, but excluding, that date.
- [NYSE removal and suspension notice filed with the SEC](https://www.sec.gov/Archives/edgar/data/876661/000087666126000352/ruleprovisionnotice.htm): Redemption funds available to holders and trading suspended on April 22. Formal May 4 listing removal is a later administrative date.
- [Ready Capital description of registered securities, section The 6.20% 2026 Notes](https://www.sec.gov/Archives/edgar/data/1527590/000162828025009464/ex4_17readycapital-fy20241.htm): USD 25 denominations, 6.20% annual interest, January 30/April 30/July 30/October 30 coupon dates, and a 360-day year of twelve 30-day months.

## ASGN — ASGN Incorporated, renamed Everforth, Inc.

| Field | Value |
| --- | --- |
| Action ID | ASGN_2026-04-24_TICKER_ALIAS |
| Kind | ticker_alias |
| Effective/accounting date | 2026-04-24 |
| Successor database identifier | EFOR |
| Successor-price multiplier | 1 |
| Price-basis reference date | 2026-05-22 |
| Reference old raw close | 19.5 |
| Reference old adjusted close | 19.5 |
| Quote-continuation start | 2026-05-26 |
| Quote-continuation end | 2026-07-30 |

Only fill documented missing accounting observations for frozen ASGN lots from 2026-05-26 through 2026-07-30. No signal, feature, training label, prediction, or eligibility changes.

Sixteen overlapping dates agree to floating-point serialization precision. Use exact unit multiplier 1; the final overlap on May 22 is exactly USD 19.50 in both sources. No in-window dividend or split event is returned by the provider.

- [Issuer corporate name/ticker change announcement or SEC current report](https://www.sec.gov/Archives/edgar/data/890564/000089056426000025/asgn-20260424.htm): Company name and NYSE ticker become Everforth/EFOR on April 24; stockholder rights are unchanged.
- [ASGN issuer name/ticker-change announcement](https://investors.everforth.com/news/news-details/2026/ASGN-Incorporated-to-Change-Corporate-Name-and-NYSE-Ticker-to-Everforth/default.aspx): April 24 transition to EFOR with unchanged CUSIP and no action required by stockholders.

## Supplemental daily prices

`../supplemental_prices.csv` contains the individual observed quotes, original provider identifiers, unit multipliers and source URLs. `../supporting_evidence.zip` preserves retrieval evidence and overlap checks under `verification/market_data_sources/`. `price_overlay_lineage.csv` enumerates the quotes actually supplied to accounting. Missing sessions were filled only by sourced observations for the same economic security; there is no interpolation or unlimited stale-price carry.
